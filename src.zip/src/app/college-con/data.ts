import * as MIT from '../../assets/collegeData/MIT'
import * as acharyainstituteoftechnologyaitbangalore from '../../assets/collegeData/acharya-institute-of-technology-ait-bangalore'
import * as allindiainstituteofmedicalsciencesaiimsnewdelhi from '../../assets/collegeData/all-india-institute-of-medical-sciences-aiims-new-delhi'
import * as amityglobalbusinessschoolagbspune from '../../assets/collegeData/amity-global-business-school-agbs-pune'
import * as amityinstituteofinformationtechnologyaiitmumbai from '../../assets/collegeData/amity-institute-of-information-technology-aiit-mumbai'
//import * as karlsruheinstituteoftechnology from '../../assets/collegeData/karlsruhe-institute-of-technology'
import * as sdminstituteformanagementdevelopmentmysore from '../../assets/collegeData/sdm-institute-for-management-development-mysore'
import * as athenaschoolofmanagementmumbai from '../../assets/collegeData/athena-school-of-management-mumbai'
import * as armedforcesmedicalcollegeafmcpune from '../../assets/collegeData/armed-forces-medical-college-afmc-pune'
import * as awadheshpratapsinghuniversity from '../../assets/collegeData/awadhesh-pratap-singh-university'
import * as balajiinstituteofmodernmanagement from '../../assets/collegeData/balaji-institute-of-modern-management-bimm-pune'
import * as bharatividyapeethcollegeofengineeringbvcoepune from '../../assets/collegeData/bharati-vidyapeeth-college-of-engineering-bvcoe-pune'
//import * as bharatividyapeethdeemeduniversity from '../../assets/collegeData/bharati-vidyapeeth-deemed-university'
import * as bharatividyapeethdentalcollegehospitalnavimumbai from '../../assets/collegeData/bharati-vidyapeeth-dental-college-hospital-navi-mumbai'
import * as bharatividyapeethdentalcollegehospitalpune from '../../assets/collegeData/bharati-vidyapeeth-dental-college-hospital-pune'
import * as bharatividyapeethdentalcollegehospitalsangli from '../../assets/collegeData/bharati-vidyapeeth-dental-college-hospital-sangli'
//import * as bharatividyapeethinstituteofmanagemententrepreneurshipdevelopment from '../../assets/collegeData/bharati-vidyapeeth-institute-of-management-entrepreneurship-development'
import * as bharatividyapeethmedicalcollegehospitalsangli from '../../assets/collegeData/bharati-vidyapeeth-medical-college-hospital-sangli'
import * as bharatividyapeethmedicalcollegepune from '../../assets/collegeData/bharati-vidyapeeth-medical-college-pune'
import * as birlainstituteoftechnologyandsciencebitspilani from '../../assets/collegeData/birla-institute-of-technology-and-science-bits-pilani'
import * as brihanmaharashtracollegeofcommercebmccpune from '../../assets/collegeData/brihan-maharashtra-college-of-commerce-bmcc-pune'
import * as bmscollegeofengineeringbangalore from '../../assets/collegeData/bms-college-of-engineering-bangalore'
import * as indianinstituteofmedicalscienceandresearchiimsrjalna from '../../assets/collegeData/indian-institute-of-medical-science-and-research-iimsr-jalna'
import * as cambridgeinstituteoftechnologycitbangalore from '../../assets/collegeData/cambridge-institute-of-technology-cit-bangalore'
//import * as camosuncollege from '../../assets/collegeData/camosun-college'
import * as drdypatilinstituteoftechnologydypitpimpripune from '../../assets/collegeData/dr-dy-patil-institute-of-technology-dypit-pimpri-pune'
import * as drdypatilmedicalcollegehospitalnavimumbai from '../../assets/collegeData/dr-dy-patil-medical-college-hospital-navi-mumbai'
import * as drdypatilmedicalcollegekolhapur from '../../assets/collegeData/dr-dy-patil-medical-college-kolhapur'
import * as drdypatilmedicalcollegepune from '../../assets/collegeData/dr-dy-patil-medical-college-pune'
import * as dypatiluniversityschoolofmanagementdypusmnavimumbai from '../../assets/collegeData/dy-patil-university-school-of-management-dypusm-navi-mumbai'
//import * as dypatilartscommercesciencecollegepune from '../../assets/collegeData/dy-patil-arts-commerce-science-college-pune'
//import * as eubusinessschoolmunich from '../../assets/collegeData/eu-business-school-munich'
//import * as europeanuniversitygeorgia from '../../assets/collegeData/european-university-georgia'
//import * as fanshawecollege from '../../assets/collegeData/fanshawe-college'
import * as gurunanakinstituteofmanagementstudiesgnimsmumbai from '../../assets/collegeData/guru-nanak-institute-of-management-studies-gnims-mumbai'
import * as jaipuriainstituteofmanagement from '../../assets/collegeData/jaipuria-institute-of-management'
//import * as jiangsuuniversity from '../../assets/collegeData/jiangsu-university'
//import * as lambtoncollege from '../../assets/collegeData/lambton-college'
//import * as lvivbusinessschoolofukrainiancatholicuniversity from '../../assets/collegeData/lviv-business-school-of-ukrainian-catholic-university'
//import * as lvivpolytechnicnationaluniversity from '../../assets/collegeData/lviv-polytechnic-national-university'
//import * as maristateuniversity from '../../assets/collegeData/mari-state-university'
//import * as mcmasteruniversity from '../../assets/collegeData/mcmaster-university'
//import * as russianpresidentialacademyofnationaleconomyandpublicadministration from '../../assets/collegeData/russian-presidential-academy-of-national-economy-and-public-administration'
import * as sagarinstituteofresearchandtechnology from '../../assets/collegeData/sagar-institute-of-research-and-technology'
import * as stjosephsinstituteofmanagementbangalore from '../../assets/collegeData/st-josephs-institute-of-management-bangalore'
import * as walchandinstituteoftechnologysolapur from '../../assets/collegeData/walchand-institute-of-technology-solapur'
//import * as budapestuniversityoftechnologyandeconomics from '../../assets/collegeData/budapest-university-of-technology-and-economics'
//import * as dalhousieuniversity from '../../assets/collegeData/dalhousie-university'
//import * as imedpune from '../../assets/collegeData/bharati-vidyapeeth-deemed-university-pune'
import * as instituteofmanagementstudiesimsghaziabad from '../../assets/collegeData/institute-of-management-studies-ims-ghaziabad'
import * as indraprasthainstituteoftechnologyandmanagementiitmnewdelhi from "../../assets/collegeData/indraprastha-institute-of-technology-and-management-iitm-new-delhi"
// import * as internationalmedicalschool from "../../assets/collegeData/international-medical-school"
import * as kirloskarinstituteofadvancedmanagementstudieskiamspune from "../../assets/collegeData/kirloskar-institute-of-advanced-management-studies-kiams-pune"
import * as kjsomaiyamedicalcollegeresearchcentrekjsmcmumbai from '../../assets/collegeData/kj-somaiya-medical-college-research-centre-kjsmc-mumbai'
import * as instituteofmanagementandentrepreneurshipdevelopmentimedpune from '../../assets/collegeData/institute-of-management-and-entrepreneurship-development-imed-pune'
import * as jspmnarhe from '../../assets/collegeData/jspm-narhe'
import * as sinhgadinstituteofmanagementandcomputerapplicationsimcanarhepune from '../../assets/collegeData/sinhgad-institute-of-management-and-computer-application-simca-narhe-pune'
import * as sinhgadinstituteofbusinessadministrationandresearchsibarkondhwapune from '../../assets/collegeData/sinhgad-institute-of-business-administration-and-research-sibar-kondhwa-pune'
import * as sinhgadcollegeofengineeringscoevadgaonpune from '../../assets/collegeData/sinhgad-college-of-engineering-scoe-vadgaon-pune'
import * as shaileshjmehtaschoolofmanagementiitbombaymumbai from '../../assets/collegeData/shailesh-j-mehta-school-of-management-iit-bombay-mumbai'
import * as scmsschoolofengineeringandtechnologykerala from '../../assets/collegeData/scms-school-of-engineering-and-technology-kerala'
import * as ramaiahinstituteoftechnologyritbangalore from '../../assets/collegeData/ramaiah-institute-of-technology-rit-bangalore'
import * as puneinstituteofcomputertechnologypictpune from '../../assets/collegeData/pune-institute-of-computer-technology-pict-pune'
import * as presidencycollegebangalore from '../../assets/collegeData/presidency-college-bangalore'
import * as theoxfordcollegeofsciencebangalore from '../../assets/collegeData/the-oxford-college-of-science-bangalore'
import * as nldalmiainstituteofmanagementstudiesandresearchmumbai from '../../assets/collegeData/nl-dalmia-institute-of-management-studies-and-research-mumbai'
import * as moderncollegeofartsscienceandcommercepune from '../../assets/collegeData/modern-college-of-arts-science-and-commerce-pune'
import * as mitschoolofmanagementpune from '../../assets/collegeData/mit-school-of-management-pune'
import * as metinstituteofcomputersciencemumbai from '../../assets/collegeData/met-institute-of-computer-science-mumbai'
import * as lalbahadurshastriinstituteofmanagementlbsimnewdelhi from '../../assets/collegeData/lal-bahadur-shastri-institute-of-management-lbsim-new-delhi'
import * as krishnainstituteofmedicalscienceskimskarad from '../../assets/collegeData/krishna-institute-of-medical-sciences-kims-karad'
import * as kjsomaiyainstituteofmanagementmumbai from '../../assets/collegeData/kj-somaiya-institute-of-management-mumbai'
import * as mitcollegeofengineeringpune from '../../assets/collegeData/mit-college-of-engineering-pune'
import * as mvjcollegeofengineeringbangalore from '../../assets/collegeData/mvj-college-of-engineering-bangalore'
import * as kristujayanticollegekjcbangalore from '../../assets/collegeData/kristu-jayanti-college-kjc-bangalore'
import * as gangainstituteoftechnologyandmanagementjhajjar from '../../assets/collegeData/ganga-institute-of-technology-and-management-jhajjar'
import * as mesgarwarecollegeofcommercepune from '../../assets/collegeData/mes-garware-college-of-commerce-pune'
import * as suryadattainstituteofbusinessmanagementandtechnologysibmtpune from '../../assets/collegeData/suryadatta-institute-of-business-management-and-technology-sibmt-pune'
import * as symbiosisinstituteofcomputerstudiesandresearchsicsrpune from '../../assets/collegeData/symbiosis-institute-of-computer-studies-and-research-sicsr-pune'
import * as symbiosisinstituteoftechnologysitpune from '../../assets/collegeData/symbiosis-institute-of-technology-sit-pune'
import * as symbiosisinstituteofbusinessmanagementsibmpune from '../../assets/collegeData/symbiosis-institute-of-business-management-sibm-pune'
import * as ternamedicalcollegenavimumbai from '../../assets/collegeData/terna-medical-college-navi-mumbai'
import * as vishwakarmainstituteoftechnologyvitpune from '../../assets/collegeData/vishwakarma-institute-of-technology-vit-pune'
import * as xavierinstituteofmanagementandentrepreneurshipbangalore from '../../assets/collegeData/xavier-institute-of-management-and-entrepreneurship-bangalore'
import * as drdypatilinstituteofmanagementandresearchdypimrpune from '../../assets/collegeData/dr-dy-patil-institute-of-management-and-research-dypimr-pune'
import * as ifmrgraduateschoolofbusinesschennai from '../../assets/collegeData/ifmr-graduate-school-of-business-chennai'
export { 
    MIT, 
    acharyainstituteoftechnologyaitbangalore,
    indraprasthainstituteoftechnologyandmanagementiitmnewdelhi,
    ifmrgraduateschoolofbusinesschennai,
    drdypatilinstituteofmanagementandresearchdypimrpune,
    xavierinstituteofmanagementandentrepreneurshipbangalore,
    vishwakarmainstituteoftechnologyvitpune,
    ternamedicalcollegenavimumbai,
    symbiosisinstituteofbusinessmanagementsibmpune,
    symbiosisinstituteoftechnologysitpune,
    symbiosisinstituteofcomputerstudiesandresearchsicsrpune,
    suryadattainstituteofbusinessmanagementandtechnologysibmtpune,
    mesgarwarecollegeofcommercepune,
    gangainstituteoftechnologyandmanagementjhajjar,
    kristujayanticollegekjcbangalore,
    mvjcollegeofengineeringbangalore,
    mitcollegeofengineeringpune,
    kjsomaiyainstituteofmanagementmumbai,
    lalbahadurshastriinstituteofmanagementlbsimnewdelhi,
    krishnainstituteofmedicalscienceskimskarad,
    metinstituteofcomputersciencemumbai,
    mitschoolofmanagementpune,
    moderncollegeofartsscienceandcommercepune,
    presidencycollegebangalore,
    nldalmiainstituteofmanagementstudiesandresearchmumbai,
    theoxfordcollegeofsciencebangalore,
    puneinstituteofcomputertechnologypictpune,
    ramaiahinstituteoftechnologyritbangalore,
    scmsschoolofengineeringandtechnologykerala,
    shaileshjmehtaschoolofmanagementiitbombaymumbai,
    sinhgadcollegeofengineeringscoevadgaonpune,
    sinhgadinstituteofbusinessadministrationandresearchsibarkondhwapune,
    jspmnarhe,
    instituteofmanagementandentrepreneurshipdevelopmentimedpune,
    kjsomaiyamedicalcollegeresearchcentrekjsmcmumbai,
    indianinstituteofmedicalscienceandresearchiimsrjalna, 
    kirloskarinstituteofadvancedmanagementstudieskiamspune,
    allindiainstituteofmedicalsciencesaiimsnewdelhi,
    amityglobalbusinessschoolagbspune,
    amityinstituteofinformationtechnologyaiitmumbai,
    sinhgadinstituteofmanagementandcomputerapplicationsimcanarhepune,
    //karlsruheinstituteoftechnology,
    sdminstituteformanagementdevelopmentmysore,
    athenaschoolofmanagementmumbai,
    awadheshpratapsinghuniversity,
    balajiinstituteofmodernmanagement,
    bharatividyapeethcollegeofengineeringbvcoepune,
    bharatividyapeethdentalcollegehospitalnavimumbai,
    bharatividyapeethdentalcollegehospitalpune,
    bharatividyapeethdentalcollegehospitalsangli,
    bharatividyapeethmedicalcollegehospitalsangli,
    bharatividyapeethmedicalcollegepune,
    birlainstituteoftechnologyandsciencebitspilani,
    brihanmaharashtracollegeofcommercebmccpune,
    instituteofmanagementstudiesimsghaziabad,
    bmscollegeofengineeringbangalore,
    cambridgeinstituteoftechnologycitbangalore,
    //camosuncollege,
    drdypatilinstituteoftechnologydypitpimpripune,
    drdypatilmedicalcollegehospitalnavimumbai,
    drdypatilmedicalcollegekolhapur,
    drdypatilmedicalcollegepune,
    dypatiluniversityschoolofmanagementdypusmnavimumbai,
    //eubusinessschoolmunich,
    //europeanuniversitygeorgia,
    //fanshawecollege,
    gurunanakinstituteofmanagementstudiesgnimsmumbai,
    jaipuriainstituteofmanagement,
    //jiangsuuniversity,
    //lambtoncollege,
    //lvivbusinessschoolofukrainiancatholicuniversity,
    //lvivpolytechnicnationaluniversity,
    //maristateuniversity,
    //mcmasteruniversity,
    //russianpresidentialacademyofnationaleconomyandpublicadministration,
    sagarinstituteofresearchandtechnology,
    stjosephsinstituteofmanagementbangalore,
    walchandinstituteoftechnologysolapur,
    //budapestuniversityoftechnologyandeconomics,
    //dalhousieuniversity,
    armedforcesmedicalcollegeafmcpune
 }
