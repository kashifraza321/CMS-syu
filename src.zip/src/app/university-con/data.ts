//import * as amityglobalbusinessschool from '../../assets/universityData/amity-global-business-school'
//import * as amityinstituteofinformationtechnologymumbai from '../../assets/universityData/amity-institute-of-information-technology'
import * as siberianstatemedicaluniversity from '../../assets/universityData/siberian-state-medical-university'
import * as saintpetersburgstateinstituteoftechnology from '../../assets/universityData/saint-petersburg-state-institute-of-technology'
import * as nationalmetallurgicalacademyofukraine from '../../assets/universityData/national-metallurgical-academy-of-ukraine'
import * as permstatemedicaluniversity from '../../assets/universityData/perm-state-medical-university'
import * as southkazakhstanmedicalacademy from '../../assets/universityData/south-kazakhstan-medical-academy'
import * as universityofregina from '../../assets/universityData/university-of-regina'
import * as kurskstatemedicaluniversity from '../../assets/universityData/kursk-state-medical-university'
import * as universityforthecreativearts from '../../assets/universityData/university-for-the-creative-arts'
import * as altaistatemedicaluniversity from '../../assets/universityData/altai-state-medical-university'
import * as bauinternationaluniversitybatumi from '../../assets/universityData/bau-international-university-batumi'
import * as universityofchittagong from '../../assets/universityData/university-of-chittagong'
import * as jalalabadstateuniversity from '../../assets/universityData/jalalabad-state-university'
import * as internationalhigherschoolofmedicine from '../../assets/universityData/international-higher-school-of-medicine'
import * as ivanovostatemedicalacademy from '../../assets/universityData/ivanovo-state-medical-academy'
import * as privolzhskyresearchmedicaluniversity from '../../assets/universityData/privolzhsky-research-medical-university'
import * as tulastateuniversity from '../../assets/universityData/tula-state-university'
import * as addinwomensmedicalcollege from '../../assets/universityData/ad-din-womens-medical-college'
import * as anwerkhanmodernmedicalcollege from '../../assets/universityData/anwer-khan-modern-medical-college'
import * as dhakacentralinternationalmedicalcollege from '../../assets/universityData/dhaka-central-international-medical-college'
import * as dhakacommunitymedicalcollege from '../../assets/universityData/dhaka-community-medical-college'
import * as drsirajulislammedicalcollege from '../../assets/universityData/dr-sirajul-islam-medical-college'
import * as enammedicalcollegeandhospital from '../../assets/universityData/enam-medical-college-and-hospital'
import * as gonoshasthayasamajvittikmedicalcollege from '../../assets/universityData/gonoshasthaya-samaj-vittik-medical-college'
import * as berlinschoolofbusinessandinnovation from '../../assets/universityData/berlin-school-of-business-and-innovation'
import * as avicennainternationalmedicaluniversity from '../../assets/universityData/avicenna-international-medical-university'
import * as bpkoiralainstituteofhealthsciences from '../../assets/universityData/b-p-koirala-institute-of-health-sciences'
import * as biratmedicalcollege from '../../assets/universityData/birat-medical-college'
import * as devdahamedicalcollegeandresearchinstitute from '../../assets/universityData/devdaha-medical-college-and-research-institute'
import * as ivanofrankivsknationaluniversityofoilandgas from '../../assets/universityData/ivano-frankivsk-national-university-of-oil-and-gas'
import * as jahurulislammedicalcollege from '../../assets/universityData/jahurul-islam-medical-college'
import * as khwajayunusalimedicalcollege from '../../assets/universityData/khwaja-yunus-ali-medical-college'
import * as kumudiniwomensmedicalcollege from '../../assets/universityData/kumudini-womens-medical-college'
import * as mainamotimedicalcollege from '../../assets/universityData/mainamoti-medical-college'
import * as monnomedicalcollegeandhospital from '../../assets/universityData/monno-medical-college-and-hospital'
import * as parkviewmedicalcollege from '../../assets/universityData/parkview-medical-college'
import * as presidentabdulhamidmedicalcollege from '../../assets/universityData/president-abdul-hamid-medical-college'
import * as primemedicalcollege from '../../assets/universityData/prime-medical-college'
import * as rangpurcommunitymedicalcollege from '../../assets/universityData/rangpur-community-medical-college'
import * as shahabuddinmedicalcollege from '../../assets/universityData/shahabuddin-medical-college'
import * as universityofexeter from '../../assets/universityData/university-of-exeter'
import * as universityofstrathclyde from '../../assets/universityData/university-of-strathclyde'
import * as velloreinstituteoftechnology from '../../assets/universityData/vellore-institute-of-technology'
import * as nationalaerospaceuniversity from '../../assets/universityData/national-aerospace-university'
import * as uzhhorodnationalmedicaluniversity from '../../assets/universityData/uzhhorod-national-medical-university'
import * as bogomoletsnationalmedicaluniversity from '../../assets/universityData/bogomolets-national-medical-university'
import * as universitycollegelondon from '../../assets/universityData/university-college-london'
import * as ternopilnationaltechnicaluniversity from '../../assets/universityData/ternopil-national-technical-university'
import * as keeleuniversity from '../../assets/universityData/keele-university'
import * as iuinternationaluniversityofappliedsciences from '../../assets/universityData/iu-international-university-of-applied-sciences'
import * as aghuniversityofscienceandtechnology from '../../assets/universityData/agh-university-of-science-and-technology'
import * as kyivschoolofeconomics from '../../assets/universityData/kyiv-school-of-economics'
import * as wroclawmedicaluniversity from '../../assets/universityData/wroclaw-medical-university'
import * as mitworldpeaceuniversity from '../../assets/universityData/mit-world-peace-university'
import * as gismabusinessschool from '../../assets/universityData/gisma-business-school'
import * as wenzhoumedicaluniversity from '../../assets/universityData/wenzhou-medical-university'
import * as glasgowcaledonianuniversity from '../../assets/universityData/glasgow-caledonian-university'
import * as tbilisimedicaluniversityhippocrates from '../../assets/universityData/tbilisi-medical-university-hippocrates'
import * as qiqiharmedicaluniversity from '../../assets/universityData/qiqihar-medical-university'
import * as medicaluniversityofverna from '../../assets/universityData/medical-university-of-verna'
import * as universityofbologna from '../../assets/universityData/university-of-bologna'
import * as immanuelkantbalticfederaluniversity from '../../assets/universityData/immanuel-kant-baltic-federal-university'
import * as peoplesfriendshipuniversity from '../../assets/universityData/peoples-friendship-university'
import * as belarusianstatemedicaluniversity from '../../assets/universityData/belarusian-state-medical-university'
import * as zaporozhyestatemedicaluniversity from '../../assets/universityData/zaporozhye-state-medical-university'
import * as batumishotarustavelistateuniversity from '../../assets/universityData/batumi-shota-rustaveli-state-university'
import * as lancasteruniversity from '../../assets/universityData/lancaster-university'
import * as balticinternationalacademy from '../../assets/universityData/baltic-international-academy'
import * as canterburychristchurchuniversity from '../../assets/universityData/canterbury-christ-church-university'
import * as corvinusuniversityofbudapest from '../../assets/universityData/corvinus-university-of-budapest'
import * as daugavpilsuniversity from '../../assets/universityData/daugavpils-university'
import * as dnipropetrovskstatemedicalacademy from '../../assets/universityData/dnipropetrovsk-state-medical-academy'
import * as donetsknationalmedicaluniversity from '../../assets/universityData/donetsk-national-medical-university'
import * as frankfurtschooloffinanceandmanagement from '../../assets/universityData/frankfurt-school-of-finance-and-management'
import * as kyivpolytechnicinstitute from '../../assets/universityData/kyiv-polytechnic-institute'
import * as kyrgyznationaluniversity from '../../assets/universityData/kyrgyz-national-university'
import * as northernstatemedicaluniversity from '../../assets/universityData/northern-state-medical-university'
import * as ogarevmordoviastateuniversity from '../../assets/universityData/ogarev-mordovia-state-university'
import * as petergreatstpetersburgpolytechnicuniversity from '../../assets/universityData/peter-great-st-petersburg-polytechnic-university'
import * as plovdivmedicaluniversity from '../../assets/universityData/plovdiv-medical-university'
import * as pskovstatepolytechnicinstitute from '../../assets/universityData/pskov-state-polytechnic-institute'
import * as pskovstateuniversity from '../../assets/universityData/pskov-state-university'
import * as smolenskstatemedicaluniversity from '../../assets/universityData/smolensk-state-medical-university'
import * as tallinnuniversityoftechnology from '../../assets/universityData/tallinn-university-of-technology'
import * as tbilisipublicuniversitymetekhi from '../../assets/universityData/tbilisi-public-university-metekhi'
import * as tribhuvanuniversity from '../../assets/universityData/tribhuvan-university'
import * as universitycanadawest from '../../assets/universityData/university-canada-west'
import * as universityofalberta from '../../assets/universityData/university-of-alberta'
import * as universityofwolverhampton from '../../assets/universityData/university-of-wolverhampton'
import * as xinjianguniversity from '../../assets/universityData/xinjiang-university'
import * as yangzhouuniversity from '../../assets/universityData/yangzhou-university'
import * as aberystwythuniversity from '../../assets/universityData/aberystwyth-university'
import * as belgorodstateuniversity from '../../assets/universityData/belgorod-state-university'
import * as bukovinianstatemedicaluniversity from '../../assets/universityData/bukovinian-state-medical-university'
import * as capitalmedicaluniversity from '../../assets/universityData/capital-medical-university'
import * as cherkasystatetechnologicaluniversity from '../../assets/universityData/cherkasy-state-technological-university'
import * as crimeanfederaluniversity from '../../assets/universityData/crimean-federal-university'
import * as danylohalytskylvivstatemedicaluniversity from '../../assets/universityData/danylo-halytsky-lviv-state-medical-university'
import * as durhamuniversity from '../../assets/universityData/durham-university'
import * as lvivpolytechnicnationaluniversity from '../../assets/universityData/lviv-polytechnic-national-university'
import * as gdanskuniversityoftechnology from '../../assets/universityData/gdansk-university-of-technology'
import * as georgiannationaluniversityseu from '../../assets/universityData/georgian-national-university-seu'
import * as jilinuniversity from '../../assets/universityData/jilin-university'
import * as jinanuniversity from '../../assets/universityData/jinan-university'
import * as kabardinobalkarianstateuniversity from '../../assets/universityData/kabardino-balkarian-state-university'
import * as kyivmedicaluniversityofuafmkiev from '../../assets/universityData/kyiv-medical-university-of-uafm-kiev'
import * as londonmetropolitanuniversity from '../../assets/universityData/london-metropolitan-university'
import * as medicaluniversityoflublin from '../../assets/universityData/medical-university-of-lublin'
import * as medicaluniversityofsilesia from '../../assets/universityData/medical-university-of-silesia'
import * as medicaluniversityofwarsaw from '../../assets/universityData/medical-university-of-warsaw'
import * as moscowuniversitytouro from '../../assets/universityData/moscow-university-touro'
import * as nicolauscopernicusuniversity from '../../assets/universityData/nicolaus-copernicus-university'
import * as nizhnynovgorodstatetechnicaluniversity from '../../assets/universityData/nizhny-novgorod-state-technical-university'
import * as northkazakhstanstateuniversity from '../../assets/universityData/north-kazakhstan-state-university'
import * as orelstateuniversity from '../../assets/universityData/orel-state-university'
import * as orenburgstatemedicaluniversity from '../../assets/universityData/orenburg-state-medical-university'
import * as poznanuniversityofmedicalscience from '../../assets/universityData/poznan-university-of-medical-science'
import * as reutlingenuniversity from '../../assets/universityData/reutlingen-university'
import * as risebauniversityofbusinessartsandtechnology from '../../assets/universityData/riseba-university-of-business-arts-and-technology'
import * as ryersonuniversity from '../../assets/universityData/ryerson-university'
import * as simonfraseruniversity from '../../assets/universityData/simon-fraser-university'
import * as stterezamedicaluniversity from '../../assets/universityData/st-tereza-medical-university'
import * as universityofbradford from '../../assets/universityData/university-of-bradford'
import * as universityofbristol from '../../assets/universityData/university-of-bristol'
import * as universityoflatvia from '../../assets/universityData/university-of-latvia'
import * as universityofottawa from '../../assets/universityData/university-of-ottawa'
import * as universityofperpetualhelp from '../../assets/universityData/university-of-perpetual-help'
import * as universityofsaskatchewan from '../../assets/universityData/university-of-saskatchewan'
import * as universityofstandrews from '../../assets/universityData/university-of-st-andrews'
import * as universityofwarmiaandmazury from '../../assets/universityData/university-of-warmia-and-mazury'
import * as vitebskstatemedicaluniversity from '../../assets/universityData/vitebsk-state-medical-university'
import * as vnkarazinkharkivnationaluniversity from '../../assets/universityData/v-n-karazin-kharkiv-national-university'
import * as volgogradstatemedicaluniversity from '../../assets/universityData/volgograd-state-medical-university'
import * as warsawuniversityoftechnology from '../../assets/universityData/warsaw-university-of-technology'
import * as yaroslavlstatemedicaluniversity from '../../assets/universityData/yaroslavl-state-medical-university'
import * as bashkirstatemedicaluniversity from '../../assets/universityData/bashkir-state-medical-university'
import * as cracowuniversityoftechnology from '../../assets/universityData/cracow-university-of-technology'
import * as fareasternfederaluniversity from '../../assets/universityData/far-eastern-federal-university'
import * as flameuniversitypune from '../../assets/universityData/flame-university-pune'
import * as gdanskmedicaluniversity from '../../assets/universityData/gdansk-medical-university'
import * as gomelstatemedicaluniversity from '../../assets/universityData/gomel-state-medical-university'
import * as guangximedicaluniversity from '../../assets/universityData/guangxi-medical-university'
import * as humboldtuniversityofberlin from '../../assets/universityData/humboldt-university-of-berlin'
import * as kalmykstateuniversity from '../../assets/universityData/kalmyk-state-university'
import * as kharkivnationaluniversityofarts from '../../assets/universityData/kharkiv-national-university-of-arts'
import * as kubanstatemedicaluniversity from '../../assets/universityData/kuban-state-medical-university'
import * as lazarskiuniversity from '../../assets/universityData/lazarski-university'
import * as medicaluniversityofpleven from '../../assets/universityData/medical-university-of-pleven'
import * as omskstatemedicaluniversity from '../../assets/universityData/omsk-state-medical-university'
import * as oshstateuniversity from '../../assets/universityData/osh-state-university'
import * as patanacademyofhealthsciences from '../../assets/universityData/patan-academy-of-health-sciences'
import * as russiannationalresearchmedicaluniversity from '../../assets/universityData/russian-national-research-medical-university'
import * as silesianuniversityoftechnology from '../../assets/universityData/silesian-university-of-technology'
import * as sofiamedicaluniversity from '../../assets/universityData/sofia-medical-university'
import * as southernmedicaluniversity from '../../assets/universityData/southern-medical-university'
import * as tyumenstatemedicaluniversity from '../../assets/universityData/tyumen-state-medical-university'
import * as universityofdebrecen from '../../assets/universityData/university-of-debrecen'
import * as universityofdhaka from '../../assets/universityData/university-of-dhaka'
import * as universityofstuttgart from '../../assets/universityData/university-of-stuttgart'
import * as universityofwarwick from '../../assets/universityData/university-of-warwick'
import * as uralstatemedicaluniversity from '../../assets/universityData/ural-state-medical-university'
import * as westkazakhstanmaratospanovstatemedicaluniversity from '../../assets/universityData/west-kazakhstan-marat-ospanov-state-medical-university'
import * as xianjiaotonguniversity from '../../assets/universityData/xian-jiaotong-university'
import * as yerevanhaybusakuniversity from '../../assets/universityData/yerevan-haybusak-university'
import * as budapestmetropolitanuniversity from '../../assets/universityData/budapest-metropolitan-university'
import * as bukharastatemedicalinstitute from '../../assets/universityData/bukhara-state-medical-institute'
import * as carletonuniversity from '../../assets/universityData/carleton-university'
import * as caucasusinternationaluniversity from "../../assets/universityData/caucasus-international-university"
import * as ivanejavakhishvilitbilisistateuniversity from '../../assets/universityData/ivane-javakhishvili-tbilisi-state-university'
import * as johannesgutenberguniversitymainz from '../../assets/universityData/johannes-gutenberg-university-mainz'
import * as klaipedauniversity from '../../assets/universityData/klaipeda-university'
import * as lvivnationalacademyofarts from '../../assets/universityData/lviv-national-academy-of-arts'
import * as odessanationalmedicaluniversity from '../../assets/universityData/odessa-national-medical-university'
import * as ryazanstatemedicaluniversity from '../../assets/universityData/ryazan-state-medical-university'
import * as tbilisiopenteachinguniversity from '../../assets/universityData/tbilisi-open-teaching-university'
import * as universityofcologne from '../../assets/universityData/university-of-cologne'
import * as universityofwindsor from '../../assets/universityData/university-of-windsor'
import * as yerevanstatemedicaluniversity from '../../assets/universityData/yerevan-state-medical-university'
import * as zaporizhzhiastateengineeringacademy from '../../assets/universityData/zaporizhzhia-state-engineering-academy'
import * as zhejiangmedicaluniversity from '../../assets/universityData/zhejiang-medical-university'
import * as astanamedicaluniversity from '../../assets/universityData/astana-medical-university'
import * as astrakhanstatemedicaluniversity from '../../assets/universityData/astrakhan-state-medical-university'
import * as bangladeshuniversityofprofessionals from '../../assets/universityData/bangladesh-university-of-professionals'
import * as davidtvildianimedicaluniversity from '../../assets/universityData/david-tvildiani-medical-university'
import * as fudanuniversity from '../../assets/universityData/fudan-university'
import * as irkutskstatemedicaluniversity from '../../assets/universityData/irkutsk-state-medical-university'
import * as jagiellonianuniversitymedicalcollege from '../../assets/universityData/jagiellonian-university-medical-college'
import * as kazakhrussianmedicaluniversity from '../../assets/universityData/kazakh-russian-medical-university'
import * as kremenchukstatetechnicaluniversity from '../../assets/universityData/kremenchuk-state-technical-university'
import * as luganskstatemedicaluniversity from '../../assets/universityData/lugansk-state-medical-university'
import * as moscowstateuniversityofcivilengineering from '../../assets/universityData/moscow-state-university-of-civil-engineering'
import * as nationaluniversityofscienceandtechnologymisis from '../../assets/universityData/national-university-of-science-and-technology-misis'
import * as northcaucasusfederaluniversity from '../../assets/universityData/north-caucasus-federal-university'
import * as pavlovfirstsaintpetersburgstatemedicaluniversity from '../../assets/universityData/pavlov-first-saint-petersburg-state-medical-university'
import * as sumystateuniversity from '../../assets/universityData/sumy-state-university'
import * as technischehochschuleingolstadt from '../../assets/universityData/technische-hochschule-ingolstadt'
import * as tverstatemedicaluniversity from '../../assets/universityData/tver-state-medical-university'
import * as ufastateaviationtechnicaluniversity from '../../assets/universityData/ufa-state-aviation-technical-university'
import * as ulyanovskstateuniversity from '../../assets/universityData/ulyanovsk-state-university'
import * as universityofeconomicsinkatowice from '../../assets/universityData/university-of-economics-in-katowice'
import * as universityofgloucestershire from '../../assets/universityData/university-of-gloucestershire'
import * as vinnitsanationalmedicaluniversity from '../../assets/universityData/vinnitsa-national-medical-university'
import * as warsawschoolofeconomicssgh from '../../assets/universityData/warsaw-school-of-economics-sgh'
import * as yorkstjohnuniversity from '../../assets/universityData/york-st-john-university'
import * as alfarabikazakhnationaluniversity from '../../assets/universityData/al-farabi-kazakh-national-university'
import * as amaschoolofmedicine from '../../assets/universityData/ama-school-of-medicine'
import * as andijanstatemedicalinstitute from '../../assets/universityData/andijan-state-medical-institute'
import * as angelesuniversityfoundation from '../../assets/universityData/angeles-university-foundation'
import * as bathspauniversity from '../../assets/universityData/bath-spa-university'
import * as carlbenzschoolofengineering from '../../assets/universityData/carl-benz-school-of-engineering'
import * as centralphilippineuniversity from '../../assets/universityData/central-philippine-university'
import * as chongqingmedicaluniversity from '../../assets/universityData/chongqing-medical-university'
import * as christuniversitybangalore from '../../assets/universityData/christ-university-bangalore'
import * as karlsruheinstituteoftechnology from '../../assets/universityData/karlsruhe-institute-of-technology'
import * as cityuniversityoflondon from '../../assets/universityData/city-university-of-london'
import * as dalianmedicaluniversity from '../../assets/universityData/dalian-medical-university'
import * as davidagmashenebeliuniversityofgeorgia from '../../assets/universityData/david-agmashenebeli-university-of-georgia'
import * as donbassstateengineeringacademy from '../../assets/universityData/donbass-state-engineering-academy'
import * as esslingenuniversityofappliedsciences from '../../assets/universityData/esslingen-university-of-applied-sciences'
import * as firstmoscowstatemedicaluniversity from '../../assets/universityData/first-moscow-state-medical-university'
import * as grodnostatemedicaluniversity from '../../assets/universityData/grodno-state-medical-university'
import * as internationalschoolofmanagementdortmund from '../../assets/universityData/international-school-of-management-dortmund'
import * as gurugobindsinghindraprasthauniversitydelhi from '../../assets/universityData/guru-gobind-singh-indraprastha-university-delhi'
import * as irkutsknationalresearchtechnicaluniversity from '../../assets/universityData/irkutsk-national-research-technical-university'
import * as jamiamilliaislamiadelhi from '../../assets/universityData/jamia-millia-islamia-delhi'
import * as karagandastatemedicaluniversity from '../../assets/universityData/karaganda-state-medical-university'
import * as kazanfederaluniversity from '../../assets/universityData/kazan-federal-university'
import * as kharkivnationalmedicaluniversity from '../../assets/universityData/kharkiv-national-medical-university'
import * as kharkivstateacademyofculture from '../../assets/universityData/kharkiv-state-academy-of-culture'
import * as khersonnationaltechnicaluniversity from '../../assets/universityData/kherson-national-technical-university'
import * as kingscollegelondon from '../../assets/universityData/kings-college-london'
import * as kokshetaustateuniversity from '../../assets/universityData/kokshetau-state-university'
import * as kyivnationaluniversityofcultureandarts from '../../assets/universityData/kyiv-national-university-of-culture-and-arts'
import * as leedsbeckettuniversity from '../../assets/universityData/leeds-beckett-university'
import * as medicaluniversityoflodz from '../../assets/universityData/medical-university-of-lodz'
import * as mkhitargosharmenianrussianinternationaluniversity from '../../assets/universityData/mkhitar-gosh-armenian-russian-international-university'
import * as moscowinstituteofphysicsandtechnology from '../../assets/universityData/moscow-institute-of-physics-and-technology'
import * as moscowpowerengineeringinstitute from '../../assets/universityData/moscow-power-engineering-institute'
import * as narseemonjeeinstituteofmanagementstudiesnmimsmumbai from '../../assets/universityData/narsee-monjee-institute-of-management-studies-nmims-mumbai'
import * as northossetianstatemedicalacademy from '../../assets/universityData/north-ossetian-state-medical-academy'
import * as novosibirsknationalresearchstateuniversity from '../../assets/universityData/novosibirsk-state-university'
import * as permstateagrotechnologicaluniversity from '../../assets/universityData/perm-state-agro-technological-university'
import * as petreshotadzetbilisimedicalacademy from '../../assets/universityData/petre-shotadze-tbilisi-medical-academy'
import * as petromohylablackseanationaluniversity from '../../assets/universityData/petro-mohyla-black-sea-national-university'
import * as poltavastatemedicalanddentaluniversity from '../../assets/universityData/poltava-state-medical-and-dental-university'
import * as queensuniversity from '../../assets/universityData/queens-university'
import * as samarastateaerospaceuniversity from '../../assets/universityData/samara-state-aerospace-university'
import * as samarastatemedicaluniversity from '../../assets/universityData/samara-state-medical-university'
import * as shandonguniversity from '../../assets/universityData/shandong-university'
import * as sichuanuniversity from '../../assets/universityData/sichuan-university'
import * as stpetersburgstatepediatricmedicaluniversity from '../../assets/universityData/st-petersburg-state-pediatric-medical-university'
import * as stpauluniversityphilippines from '../../assets/universityData/st-paul-university-philippines'
import * as symbiosisinternationaluniversitysiupune from '../../assets/universityData/symbiosis-international-university-siu-pune'
import * as tambovstateuniversity from '../../assets/universityData/tambov-state-university'
import * as universityofedinburgh from '../../assets/universityData/university-of-edinburgh'
import * as transportandtelecommunicationinstitute from '../../assets/universityData/transport-and-telecommunication-institute'
import * as universityofmanchester from '../../assets/universityData/university-of-manchester'
import * as universityofnorthernphilippines from '../../assets/universityData/university-of-northern-philippines'
import * as universityofpavia from '../../assets/universityData/university-of-pavia'
import * as universityofrajshahi from '../../assets/universityData/university-of-rajshahi'
import * as universityofsouthwales from '../../assets/universityData/university-of-south-wales'
import * as universityoftraditionalmedicine from '../../assets/universityData/university-of-traditional-medicine'
import * as vilniauskolegijauniversityofappliedsciences from '../../assets/universityData/vilniaus-kolegija-university-of-applied-sciences'
import * as warsawuniversityoftechnologybusinessschool from '../../assets/universityData/warsaw-university-of-technology-business-school'
import * as wuhanuniversity from '../../assets/universityData/wuhan-university'
import * as armenianmedicalinstitute from '../../assets/universityData/armenian-medical-institute'
import * as iliastateuniversity from '../../assets/universityData/ilia-state-university'
import * as collegiumdavinci from '../../assets/universityData/collegium-da-vinci'
import * as georgianamericanuniversity from '../../assets/universityData/georgian-american-university'
import * as kazakhnationalmedicaluniversity from '../../assets/universityData/kazakh-national-medical-university'
import * as kharkivinternationalmedicaluniversity from '../../assets/universityData/kharkiv-international-medical-university'
import * as ningxiauniversity from '../../assets/universityData/ningxia-university'
import * as royalcollegeofart from '../../assets/universityData/royal-college-of-art'
import * as tomskpolytechnicuniversity from '../../assets/universityData/tomsk-polytechnic-university'
import * as ukrainianstatechemicaltechnologyuniversity from '../../assets/universityData/ukrainian-state-chemical-technology-university'
import * as universityofsussex from '../../assets/universityData/university-of-sussex'
import * as baumanmoscowstatetechnicaluniversity from '../../assets/universityData/bauman-moscow-state-technical-university'
import * as chuvashstateuniversity from '../../assets/universityData/chuvash-state-university'
import * as itmouniversity from '../../assets/universityData/itmo-university'
import * as kazakhmedicaluniversityofcontinuingeducation from '../../assets/universityData/kazakh-medical-university-of-continuing-education'
import * as kharkivnationaluniversityofradioelectronics from '../../assets/universityData/kharkiv-national-university-of-radio-electronics'
import * as kingstonuniversitylondon from '../../assets/universityData/kingston-university-london'
import * as lodzuniversityoftechnology from '../../assets/universityData/lodz-university-of-technology'
import * as lomonosovmoscowstateuniversitybusinessschool from '../../assets/universityData/lomonosov-moscow-state-university-business-school'
import * as lomonosovmoscowstateuniversity from '../../assets/universityData/lomonosov-moscow-state-university'
import * as middlesexuniversitylondon from '../../assets/universityData/middlesex-university-london'
import * as newvisionuniversity from '../../assets/universityData/new-vision-university'
import * as shahjalaluniversityofscienceandtechnology from '../../assets/universityData/shahjalal-university-of-science-and-technology'
import * as shivajiuniversitykolhapur from '../../assets/universityData/shivaji-university-kolhapur'
import * as southwesternuniversityphinma from '../../assets/universityData/southwestern-university-phinma'
import * as universityofbedfordshire from '../../assets/universityData/university-of-bedfordshire'
import * as universityofcambridge from '../../assets/universityData/university-of-cambridge'
import * as universityofmannheim from '../../assets/universityData/university-of-mannheim'
import * as universityofmiskolc from '../../assets/universityData/university-of-miskolc'
import * as vistulauniversity from '../../assets/universityData/vistula-university'
import * as bppuniversity from '../../assets/universityData/bpp-university'
import * as cardiffmetropolitanuniversity from '../../assets/universityData/cardiff-metropolitan-university'
import * as cebuinstituteofmedicine from '../../assets/universityData/cebu-institute-of-medicine'
import * as estonianacademyofarts from '../../assets/universityData/estonian-academy-of-arts'
import * as geomedistateuniversity from '../../assets/universityData/geomedi-state-university'
import * as kemerovostatemedicaluniversity from '../../assets/universityData/kemerovo-state-medical-university'
import * as kyrgyzrussianslavicuniversity from '../../assets/universityData/kyrgyz-russian-slavic-university'
import * as moscowaviationinstitute from '../../assets/universityData/moscow-aviation-institute'
import * as semeystatemedicaluniversity from '../../assets/universityData/semey-state-medical-university'
import * as stavropolstatemedicaluniversity from '../../assets/universityData/stavropol-state-medical-university'
import * as szentistvanuniversity from '../../assets/universityData/szent-istvan-university'
import * as tarasshevchenkonationaluniversityofkyiv from '../../assets/universityData/taras-shevchenko-national-university-of-kyiv'
import * as tashkentmedicalacademy from '../../assets/universityData/tashkent-medical-academy'
import * as universityofgeorgiatbilisi from '../../assets/universityData/university-of-georgia-tbilisi'
import * as universityofpisa from '../../assets/universityData/university-of-pisa'
import * as bocconiuniversity from '../../assets/universityData/bocconi-university'
import * as bruneluniversitylondon from '../../assets/universityData/brunel-university-london'
import * as budapestuniversityoftechnologyandeconomics from '../../assets/universityData/budapest-university-of-technology-and-economics'
import * as camosuncollege from '../../assets/universityData/camosun-college'
import * as chechenstateuniversity from '../../assets/universityData/chechen-state-university'
import * as dagestanstatemedicaluniversity from '../../assets/universityData/dagestan-state-medical-university'
import * as dalhousieuniversity from '../../assets/universityData/dalhousie-university'
import * as eubusinessschoolmunich from '../../assets/universityData/eu-business-school-munich'
import * as fanshawecollege from '../../assets/universityData/fanshawe-college'
import * as lambtoncollege from '../../assets/universityData/lambton-college'
import * as lvivbusinessschoolofukrainiancatholicuniversity from '../../assets/universityData/lviv-business-school-of-ukrainian-catholic-university'
import * as maristateuniversity from '../../assets/universityData/mari-state-university'
import * as mcmasteruniversity from '../../assets/universityData/mcmaster-university'
import * as medicaluniversityofbialystok from '../../assets/universityData/medical-university-of-bialystok'
import * as moscowstateuniversityoffinechemicaltechnologies from '../../assets/universityData/moscow-state-university-of-fine-chemical-technologies'
import * as munichbusinessschool from '../../assets/universityData/munich-business-school'
import * as novosibirskstateuniversity from '../../assets/universityData/novosibirsk-state-university'
import * as pacificstatemedicaluniversity from '../../assets/universityData/pacific-state-medical-university'
import * as penzastatemedicaluniversity from '../../assets/universityData/penza-state-medical-university'
import * as russianpresidentialacademyofnationaleconomyandpublicadministration from '../../assets/universityData/russian-presidential-academy-of-national-economy-and-public-administration'
import * as saratovstatemedicaluniversity from '../../assets/universityData/saratov-state-medical-university'
import * as sheridancollege from '../../assets/universityData/sheridan-college'
import * as tairunnessamemorialmedicalcollege from '../../assets/universityData/tairunnessa-memorial-medical-college'
import * as tallinnhealthcarecollege from '../../assets/universityData/tallinn-health-care-college'
import * as tbilisistatemedicaluniversity from '../../assets/universityData/tbilisi-state-medical-university'
import * as ternopilnationalmedicaluniversity from '../../assets/universityData/ternopil-national-medical-university'
import * as theuniversityoflaw from '../../assets/universityData/the-university-of-law'
import * as trakiauniversity from '../../assets/universityData/trakia-university'
import * as universityoflincoln from '../../assets/universityData/university-of-lincoln'
import * as universityofoxford from '../../assets/universityData/university-of-oxford'
import * as universityofsurrey from '../../assets/universityData/university-of-surrey'
import * as universityofulm from '../../assets/universityData/university-of-ulm'
import * as usbanglamedicalcollege from '../../assets/universityData/us-bangla-medical-college'
import * as voronezhstatemedicaluniversity from '../../assets/universityData/voronezh-state-medical-university'
import * as wroclawuniversityoftechnology from '../../assets/universityData/wroclaw-university-of-technology'
import * as amecbicolchristiancollegeofmedicine from '../../assets/universityData/amec-bicol-christian-college-of-medicine'
import * as easteuropeanuniversity from '../../assets/universityData/east-european-university'
import * as romebusinessschool from '../../assets/universityData/rome-business-school'
import * as universityofpadua from '../../assets/universityData/university-of-padua'
import * as universityofsalford from '../../assets/universityData/university-of-salford'
import * as asianinstitutemanagementphilippines from '../../assets/universityData/asian-institute-management-philippines'
import * as asianmedicalinstitute from '../../assets/universityData/asian-medical-institute'
import * as belfastmetropolitancollege from '../../assets/universityData/belfast-metropolitan-college'
import * as brokenshirecollegeschoolofmedicine from '../../assets/universityData/brokenshire-college-school-of-medicine'
import * as davaomedicalschoolfoundation from '../../assets/universityData/davao-medical-school-foundation'
import * as emilioaguinaldocollegemanila from '../../assets/universityData/emilio-aguinaldo-college-manila'
import * as henleybusinessschool from '../../assets/universityData/henley-business-school'
import * as kathmandumedicalcollege from '../../assets/universityData/kathmandu-medical-college'
import * as kharkivstateacademyofdesignandarts from '../../assets/universityData/kharkiv-state-academy-of-design-and-arts'
import * as liceocollegeofmedicine from '../../assets/universityData/liceo-college-of-medicine'
import * as liverpoolhopeuniversity from '../../assets/universityData/liverpool-hope-university'
import * as londonschoolofeconomicsandpoliticalsciencelondon from '../../assets/universityData/london-school-of-economics-and-political-science-london'
import * as manipalcollegeofmedicalsciences from '../../assets/universityData/manipal-college-of-medical-sciences'
import * as moscowschoolofmanagementskolkovo from '../../assets/universityData/moscow-school-of-management-skolkovo'
import * as newcollegedurham from '../../assets/universityData/new-college-durham'
import * as ramonvdelrosariocollegeofbusiness from '../../assets/universityData/ramon-v-del-rosario-college-of-business'
import * as uvgullascollegeofmedicine from '../../assets/universityData/uv-gullas-college-of-medicine'
import * as washingtonsycipgraduateschoolofbusiness from '../../assets/universityData/washington-sycip-graduate-school-of-business'
import * as europeanuniversitygeorgia from '../../assets/universityData/european-university-georgia'
import * as jiangsuuniversity from '../../assets/universityData/jiangsu-university'
import * as uibinternationalmedicalschool from '../../assets/universityData/uib-international-medical-school'
import * as bharatividyapeethdeemeduniversitypune from '../../assets/universityData/bharati-vidyapeeth-deemed-university-pune'
import * as rostovstatemedicaluniversity from '../../assets/universityData/rostov-state-medical-university'
import * as izhevskstatemedicalacademy from '../../assets/universityData/izhevsk-state-medical-academy'
import * as ivanofrankivsknationalmedicaluniversity from '../../assets/universityData/ivano-frankivsk-national-medical-university'
import * as kyrgyzstatemedicalacademy from '../../assets/universityData/kyrgyz-state-medical-academy'
import * as lyceumnorthwesternuniversity from '../../assets/universityData/lyceum-northwestern-university'
import * as manilacentraluniversity from '../../assets/universityData/manila-central-university'
import * as nanjingmedicaluniversity from '../../assets/universityData/nanjing-medical-university'
import * as ourladyoffatimauniversity from '../../assets/universityData/our-lady-of-fatima-university'
import * as samarkandstatemedicalinstitute from '../../assets/universityData/samarkand-state-medical-institute'
import * as southuralstateuniversity from '../../assets/universityData/south-ural-state-university'
import * as tashkentstatedentalinstitute from '../../assets/universityData/tashkent-state-dental-institute'
import * as universityofsantotomas from '../../assets/universityData/university-of-santo-tomas'
import * as vinnytsianationaltechnicaluniversity from '../../assets/universityData/vinnytsia-national-technical-university'
import * as poznanuniversityoftechnology from '../../assets/universityData/poznan-university-of-technology'
import * as akakitseretelistateuniversity from '../../assets/universityData/akaki-tsereteli-state-university'
import * as kazanstatemedicaluniversity from '../../assets/universityData/kazan-state-medical-university'
import * as northeasternfederaluniversity from '../../assets/universityData/north-eastern-federal-university'
import * as jalalabadragibrabeyamedicalcollege from '../../assets/universityData/jalalabad-ragib-rabeya-medical-college'
import * as tianjinmedicaluniversity from '../../assets/universityData/tianjin-medical-university'
import * as nationalaviationuniversity from '../../assets/universityData/national-aviation-university'
import * as universityofbonn from '../../assets/universityData/university-of-bonn'
import * as rwthaachenuniversity from '../../assets/universityData/rwth-aachen-university'
import * as dhakanationalmedicalcollege from '../../assets/universityData/dhaka-national-medical-college'
export { 
    
    //amityglobalbusinessschool,
    //amityinstituteofinformationtechnologymumbai,
    rwthaachenuniversity,
    dhakanationalmedicalcollege,
    universityofbonn,
    northeasternfederaluniversity,
    nationalaviationuniversity,
    jalalabadragibrabeyamedicalcollege,
    vinnytsianationaltechnicaluniversity,
    kazanstatemedicaluniversity,
    iliastateuniversity,
    akakitseretelistateuniversity,
    poznanuniversityoftechnology,
    universityofsantotomas,
    tashkentstatedentalinstitute,
    southuralstateuniversity,
    samarkandstatemedicalinstitute,
    manilacentraluniversity,
    ourladyoffatimauniversity,
    nanjingmedicaluniversity,
    lyceumnorthwesternuniversity,
    kyrgyzstatemedicalacademy,
    europeanuniversitygeorgia,
    karlsruheinstituteoftechnology,
    bharatividyapeethdeemeduniversitypune,
    lvivpolytechnicnationaluniversity,
    jiangsuuniversity,
    washingtonsycipgraduateschoolofbusiness,
    moscowstateuniversityoffinechemicaltechnologies,
    ramonvdelrosariocollegeofbusiness,
    uvgullascollegeofmedicine,
    moscowschoolofmanagementskolkovo,
    newcollegedurham,
    londonschoolofeconomicsandpoliticalsciencelondon,
    manipalcollegeofmedicalsciences,
    liceocollegeofmedicine,
    liverpoolhopeuniversity,
    kathmandumedicalcollege,
    kharkivstateacademyofdesignandarts,
    emilioaguinaldocollegemanila,
    henleybusinessschool,
    brokenshirecollegeschoolofmedicine,
    davaomedicalschoolfoundation,
    asianmedicalinstitute,
    belfastmetropolitancollege,
    universityofsalford,
    asianinstitutemanagementphilippines,
    romebusinessschool,
    universityofpadua,
    amecbicolchristiancollegeofmedicine,
    easteuropeanuniversity,
    ivanofrankivsknationalmedicaluniversity,
    rostovstatemedicaluniversity,
    izhevskstatemedicalacademy,
    voronezhstatemedicaluniversity,
    wroclawuniversityoftechnology,
    universityofulm,
    usbanglamedicalcollege,
    universityofoxford,
    universityofsurrey,
    trakiauniversity,
    universityoflincoln,
    ternopilnationalmedicaluniversity,
    theuniversityoflaw,
    tbilisistatemedicaluniversity,
    tairunnessamemorialmedicalcollege,
    tallinnhealthcarecollege,
    sheridancollege,
    saratovstatemedicaluniversity,
    penzastatemedicaluniversity,
    russianpresidentialacademyofnationaleconomyandpublicadministration,
    novosibirskstateuniversity,
    pacificstatemedicaluniversity,
    munichbusinessschool,
    mcmasteruniversity,
    medicaluniversityofbialystok,
    budapestuniversityoftechnologyandeconomics,
    lvivbusinessschoolofukrainiancatholicuniversity,
    maristateuniversity,
    lambtoncollege,
    eubusinessschoolmunich,
    fanshawecollege,
    dagestanstatemedicaluniversity,
    dalhousieuniversity,
    chechenstateuniversity,
    camosuncollege,
    universityofgeorgiatbilisi,
    bocconiuniversity,
    bruneluniversitylondon,
    universityofpisa,
    moscowaviationinstitute,
    tarasshevchenkonationaluniversityofkyiv,
    tashkentmedicalacademy,
    stavropolstatemedicaluniversity,
    szentistvanuniversity,
    semeystatemedicaluniversity,
    kemerovostatemedicaluniversity,
    kyrgyzrussianslavicuniversity,
    estonianacademyofarts,
    geomedistateuniversity,
    vistulauniversity,
    cardiffmetropolitanuniversity,
    cebuinstituteofmedicine,
    bppuniversity,
    universityofmannheim,
    universityofmiskolc,
    universityofbedfordshire,
    universityofcambridge,
    lodzuniversityoftechnology,
    shivajiuniversitykolhapur,
    southwesternuniversityphinma,
    newvisionuniversity,
    shahjalaluniversityofscienceandtechnology,
    lomonosovmoscowstateuniversity,
    middlesexuniversitylondon,
    lomonosovmoscowstateuniversitybusinessschool,
    uibinternationalmedicalschool,
    kharkivinternationalmedicaluniversity,
    kharkivnationaluniversityofradioelectronics,
    kingstonuniversitylondon,
    itmouniversity,
    kazakhmedicaluniversityofcontinuingeducation,
    ukrainianstatechemicaltechnologyuniversity,
    baumanmoscowstatetechnicaluniversity,
    chuvashstateuniversity,
    universityofsussex,
    royalcollegeofart,
    tomskpolytechnicuniversity,
    ningxiauniversity,
    tianjinmedicaluniversity,
    shahabuddinmedicalcollege,
    georgianamericanuniversity,
    kazakhnationalmedicaluniversity,
    armenianmedicalinstitute,
    collegiumdavinci,
    wuhanuniversity,
    vilniauskolegijauniversityofappliedsciences,
    warsawuniversityoftechnologybusinessschool,
    universityofsouthwales,
    universityoftraditionalmedicine,
    universityofmanchester,
    universityofpavia,
    universityofrajshahi,
    universityofnorthernphilippines,
    universityofedinburgh,
    transportandtelecommunicationinstitute,
    symbiosisinternationaluniversitysiupune,
    tambovstateuniversity,
    stpetersburgstatepediatricmedicaluniversity,
    stpauluniversityphilippines,
    shandonguniversity,
    sichuanuniversity,
    poltavastatemedicalanddentaluniversity,
    samarastateaerospaceuniversity,
    samarastatemedicaluniversity,
    queensuniversity,
    permstateagrotechnologicaluniversity,
    petromohylablackseanationaluniversity,
    petreshotadzetbilisimedicalacademy,
    northossetianstatemedicalacademy,
    novosibirsknationalresearchstateuniversity,
    moscowpowerengineeringinstitute,
    narseemonjeeinstituteofmanagementstudiesnmimsmumbai,
    moscowinstituteofphysicsandtechnology,
    medicaluniversityoflodz,
    mkhitargosharmenianrussianinternationaluniversity,
    kyivnationaluniversityofcultureandarts,
    leedsbeckettuniversity,
    kingscollegelondon,
    kokshetaustateuniversity,
    kharkivstateacademyofculture,
    khersonnationaltechnicaluniversity,
    kharkivnationalmedicaluniversity,
    karagandastatemedicaluniversity,
    kazanfederaluniversity,
    irkutsknationalresearchtechnicaluniversity,
    jamiamilliaislamiadelhi,
    internationalschoolofmanagementdortmund,
    gurugobindsinghindraprasthauniversitydelhi,
    grodnostatemedicaluniversity,
    esslingenuniversityofappliedsciences,
    firstmoscowstatemedicaluniversity,
    davidagmashenebeliuniversityofgeorgia,
    donbassstateengineeringacademy,
    cityuniversityoflondon,
    dalianmedicaluniversity,
    christuniversitybangalore,
    centralphilippineuniversity,
    chongqingmedicaluniversity,
    bathspauniversity,
    carlbenzschoolofengineering,
    andijanstatemedicalinstitute,
    angelesuniversityfoundation,
    alfarabikazakhnationaluniversity,
    amaschoolofmedicine,
    yorkstjohnuniversity,
    vinnitsanationalmedicaluniversity,
    warsawschoolofeconomicssgh,
    universityofeconomicsinkatowice,
    universityofgloucestershire,
    ulyanovskstateuniversity,
    tverstatemedicaluniversity,
    ufastateaviationtechnicaluniversity,
    technischehochschuleingolstadt,
    sumystateuniversity,
    northcaucasusfederaluniversity,
    pavlovfirstsaintpetersburgstatemedicaluniversity,
    moscowstateuniversityofcivilengineering,
    nationaluniversityofscienceandtechnologymisis,
    kremenchukstatetechnicaluniversity,
    luganskstatemedicaluniversity,
    kazakhrussianmedicaluniversity,
    irkutskstatemedicaluniversity,
    jagiellonianuniversitymedicalcollege,
    davidtvildianimedicaluniversity,
    bangladeshuniversityofprofessionals,
    fudanuniversity,
    astanamedicaluniversity,
    astrakhanstatemedicaluniversity,
    zaporizhzhiastateengineeringacademy,
    zhejiangmedicaluniversity,
    universityofwindsor,
    yerevanstatemedicaluniversity,
    tbilisiopenteachinguniversity,
    universityofcologne,
    ryazanstatemedicaluniversity,
    lvivnationalacademyofarts,
    odessanationalmedicaluniversity,
    johannesgutenberguniversitymainz,
    klaipedauniversity,
    bukharastatemedicalinstitute,
    caucasusinternationaluniversity,
    ivanejavakhishvilitbilisistateuniversity,
    carletonuniversity,
    westkazakhstanmaratospanovstatemedicaluniversity,
    yerevanhaybusakuniversity,
    budapestmetropolitanuniversity,
    xianjiaotonguniversity,
    universityofwarwick,
    uralstatemedicaluniversity,
    universityofdhaka,
    universityofstuttgart,
    tyumenstatemedicaluniversity,
    universityofdebrecen,
    southernmedicaluniversity,
    silesianuniversityoftechnology,
    sofiamedicaluniversity,
    patanacademyofhealthsciences,
    russiannationalresearchmedicaluniversity,
    oshstateuniversity,
    medicaluniversityofpleven,
    omskstatemedicaluniversity,
    kubanstatemedicaluniversity,
    lazarskiuniversity,
    kalmykstateuniversity,
    kharkivnationaluniversityofarts,
    guangximedicaluniversity,
    humboldtuniversityofberlin,
    gomelstatemedicaluniversity,
    gdanskmedicaluniversity,
    flameuniversitypune,
    fareasternfederaluniversity,
    cracowuniversityoftechnology,
    bashkirstatemedicaluniversity,
    yaroslavlstatemedicaluniversity,
    warsawuniversityoftechnology,
    volgogradstatemedicaluniversity,
    vnkarazinkharkivnationaluniversity,
    vitebskstatemedicaluniversity,
    universityofwarmiaandmazury,
    universityofstandrews,
    universityofsaskatchewan,
    universityofperpetualhelp,
    universityofottawa,
    universityoflatvia,
    universityofbristol,
    stterezamedicaluniversity,
    universityofbradford,
    simonfraseruniversity,
    risebauniversityofbusinessartsandtechnology,
    ryersonuniversity,
    reutlingenuniversity,
    poznanuniversityofmedicalscience,
    northkazakhstanstateuniversity,
    orenburgstatemedicaluniversity,
    orelstateuniversity,
    nizhnynovgorodstatetechnicaluniversity,
    nicolauscopernicusuniversity,
    moscowuniversitytouro,
    medicaluniversityofwarsaw,
    medicaluniversityofsilesia,
    medicaluniversityoflublin,
    londonmetropolitanuniversity,
    kyivmedicaluniversityofuafmkiev,
    kabardinobalkarianstateuniversity,
    jinanuniversity,
    jilinuniversity,
    georgiannationaluniversityseu,
    gdanskuniversityoftechnology,
    durhamuniversity,
    danylohalytskylvivstatemedicaluniversity,
    crimeanfederaluniversity,
    cherkasystatetechnologicaluniversity,
    bukovinianstatemedicaluniversity,
    capitalmedicaluniversity,
    belgorodstateuniversity,
    aberystwythuniversity,
    xinjianguniversity,
    yangzhouuniversity,
    universityofwolverhampton,
    universityofalberta,
    universitycanadawest,
    tribhuvanuniversity,
    tbilisipublicuniversitymetekhi,
    tallinnuniversityoftechnology,
    smolenskstatemedicaluniversity,
    pskovstateuniversity,
    pskovstatepolytechnicinstitute,
    plovdivmedicaluniversity,
    petergreatstpetersburgpolytechnicuniversity,
    ogarevmordoviastateuniversity,
    northernstatemedicaluniversity,
    kyrgyznationaluniversity,
    kyivpolytechnicinstitute,
    frankfurtschooloffinanceandmanagement,
    donetsknationalmedicaluniversity,
    daugavpilsuniversity,
    dnipropetrovskstatemedicalacademy,
    canterburychristchurchuniversity,
    corvinusuniversityofbudapest,
    balticinternationalacademy,
    lancasteruniversity,
    batumishotarustavelistateuniversity,
    belarusianstatemedicaluniversity,
    zaporozhyestatemedicaluniversity,
    peoplesfriendshipuniversity,
    universityofbologna,
    qiqiharmedicaluniversity,
    medicaluniversityofverna,
    tbilisimedicaluniversityhippocrates,
    wenzhoumedicaluniversity,
    glasgowcaledonianuniversity,
    gismabusinessschool,
    wroclawmedicaluniversity,
    mitworldpeaceuniversity,
    kyivschoolofeconomics,
    iuinternationaluniversityofappliedsciences,
    aghuniversityofscienceandtechnology,
    ternopilnationaltechnicaluniversity,
    keeleuniversity,
    universitycollegelondon,
    bogomoletsnationalmedicaluniversity,
    uzhhorodnationalmedicaluniversity,
    nationalaerospaceuniversity,
    universityofstrathclyde,
    velloreinstituteoftechnology,
    universityofexeter,
    siberianstatemedicaluniversity,
    rangpurcommunitymedicalcollege,
    primemedicalcollege,
    presidentabdulhamidmedicalcollege,
    parkviewmedicalcollege,
    avicennainternationalmedicaluniversity,
    bpkoiralainstituteofhealthsciences,
    saintpetersburgstateinstituteoftechnology,
    nationalmetallurgicalacademyofukraine,
    permstatemedicaluniversity,
    southkazakhstanmedicalacademy,
    universityofregina,
    kurskstatemedicaluniversity,
    universityforthecreativearts,
    altaistatemedicaluniversity,
    bauinternationaluniversitybatumi,
    universityofchittagong,
    jalalabadstateuniversity,
    internationalhigherschoolofmedicine,
    ivanovostatemedicalacademy,
    privolzhskyresearchmedicaluniversity,
    tulastateuniversity,
    addinwomensmedicalcollege,
    anwerkhanmodernmedicalcollege,
    dhakacentralinternationalmedicalcollege,
    dhakacommunitymedicalcollege,
    drsirajulislammedicalcollege,
    enammedicalcollegeandhospital,
    gonoshasthayasamajvittikmedicalcollege,
    berlinschoolofbusinessandinnovation,
    biratmedicalcollege,
    devdahamedicalcollegeandresearchinstitute,
    ivanofrankivsknationaluniversityofoilandgas,
    jahurulislammedicalcollege,
    khwajayunusalimedicalcollege,
    kumudiniwomensmedicalcollege,
    mainamotimedicalcollege,
    monnomedicalcollegeandhospital,
    immanuelkantbalticfederaluniversity,
    
    //christuniversitybangalore

 }
