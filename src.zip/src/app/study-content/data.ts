import * as demo from '../../assets/study-con/demo'

export {
    demo
}