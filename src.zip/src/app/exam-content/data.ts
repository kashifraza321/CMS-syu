import * as MIT from '../../assets/collegeData/MIT'
import * as acharyainstituteoftechnology from '../../assets/collegeData/acharya-institute-of-technology-ait-bangalore'
import * as allindiainstituteofmedicalsciencedelhi from '../../assets/collegeData/all-india-institute-of-medical-sciences-aiims-new-delhi'
import * as amityglobalbusinessschool from '../../assets/collegeData/amity-global-business-school-agbs-pune'
import * as amityinstituteofinformationtechnologymumbai from '../../assets/collegeData/amity-institute-of-information-technology-aiit-mumbai'
import * as neetpgexam from '../../assets/examData/neet-pg-exam'
import * as fmgeexam from '../../assets/examData/fmge-exam'
import * as neetugexam from '../../assets/examData/neet-ug-exam'
import * as internationalfoundationofmedicineifom from '../../assets/examData/international-foundation-of-medicine-ifom'
export { 
    MIT,
    acharyainstituteoftechnology, 
    allindiainstituteofmedicalsciencedelhi,
    amityglobalbusinessschool, 
    amityinstituteofinformationtechnologymumbai,
    neetpgexam,
    fmgeexam,
    neetugexam,
    internationalfoundationofmedicineifom

 }
