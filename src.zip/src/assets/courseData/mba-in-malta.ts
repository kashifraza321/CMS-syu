// export const engineeringinukraine= {
//     "Title": "ENGINEERING IN UKRAINE",
//     "shortTitle": "Engineering in Ukraine",
//     "location": " ",
//     "type": "bb",
//     "rating": "vv",
//     "shareLink": "www.google.com",
//     data: [


        // {
        //     type: 'text',
        //     title: '',
        //     img: '',
        //     data: ''
        // },

        // {
        //     "type": "table",
        //     "title": "",
        //     "info": "",
        //     "col": [
        //     ],
        //     "row": [
        //         ["<b></b>", ""],
        //         ["<b></b>", ""],
        //         ["<b></b>", ""],
        //         ["<b></b>", ""],
        //         ["<b></b>", ""],
        //         ["<b></b>", ""],
        //         ["<b></b>", ""],
        //         ["<b></b>", ""],
        //         ["<b></b>", ""],
        //         ["<b></b>", ""],
        //         ["<b></b>", ""],


        //     ]
        // },
//      {
        //     "type": "list-bollet",
        //     "title": "",
        //     "info": "<b></b>",
        //     "img": '',
        //     "data": [
        //         "",
        //         "",
        //         "",
        //         "",
        //         "",
        //         "",
        //         "",
        //         "",


        //     ]
        // },


        // {
        //     type:'meta',
        //     data:[
        //       {name: "description" , content:"", itemprop:"", property: "",scheme:'' },
        //       {name: "og:type" , content:"website", itemprop:"", property: "", },
        //       {name: "og:image" , content:"", itemprop:"", property: "",scheme:'' },
        //       {name: "og:description" , content:"", itemprop:"", property: "",scheme:'' },
        //       {name: "og:url" , content:"", itemprop:"", property: "",scheme:'' },


        //       {name: "charset" , content:"utf-8", itemprop:"", property: "",scheme:'' },
        //       {name: "google" , content:"notranslate", itemprop:"", property: "",scheme:'' },
        //       {name: "viewport" , content:"width=device-width, initial-scale=1, shrink-to-fit=no, maximum-scale=1, user-scalable=no", itemprop:"", property: "",scheme:'' },




        //     ]
        //   },
        //   {
        //     type:'link',
        //     data:[
        //       { rel:'alternate', href:'https://www.selectyouruniversity.com/mba-in-malta hreflang=en-Us '},
        //       { rel:'canonical', href:''},
        //       { rel:'icon', href:'images/fevicon.png type="image/png"'},
        //     ],
        //     url:""
        //   },
        //   {
        //     type:"page-Title",
        //     data:"",
        //   }

    // ]}


    export const  mbainmalta= {
        "Title": "MBA IN MALTA",
        "shortTitle": " MBA in Malta",
        "location": " ",
        "type": "bb",
        "rating": "vv",
        "shareLink": "www.google.com",
        "url":"mba-in-malta",
        "info": [


            {
                type: 'text',
                title: 'MBA Course in Malta',
                img: 'https://www.selectyouruniversity.com/images/mba-in-malta.jpg',
                data: '<p><b>MBA in Malta</b> is a popular study destination for international students. MBA universities in Malta offer a Master’s education in various specializations. Business schools in Malta are accredited and recognized by the number of international authorities.</p><p> There are various schools in Malta that offer quality learning in the fields of business and management studies.</p><br><p>The cost of studying an MBA in Malta may vary as per the choice of students whether he will select an on-campus apartment or an off-campus apartment, room selection, cost of books or other incidentals. After completion of course, students will be awarded an MBA degree in the respective specialized fields. </p>                '
            },

            {
                "type": "table",
                "title": "MBA in Malta 2022: Course Highlights",
                "info": "<b>Following are the quick Overview of MBA in Malta:</b>",
                "col": [
                ],
                "row": [
                    ["<b>Intake for MBBS Course	</b>", "August"],
                    ["<b>IELTS/TOEFL	</b>", "Yes, Compulsory"],
                    ["<b>Course Duration	</b>", "2 to 2.5 years"],
                    ["<b>Work Experience	</b>", "Minimum of 2 years"],
                    ["<b>Annual Course Fees	</b>", "INR 5 lakhs upwards"],
                    ["<b>Types of MBA Program	</b>", "Full-time/Executive MBA"],

                ]
            },
         {
                "type": "list-bollet",
                "title": "Why Study MBA in Malta?",
                "info": "<b>Following are the top benefits of studying MBA in Malta:</b>",
                "img": '',
                "data": [
                    "MBA degree from Malta is globally accepted.",
                    "Opportunity to study under the renowned faculty with an advanced learning environment.",
                    "Fully equipped classrooms, accommodation facilities.",
                    "While studying MBA in Malta, you can get access to more than 50,000 online study materials.",
                    "MBA schools in Malta offer a diverse environment by adapting the different nationalities and cultures beyond the core academic achievement.",
                    " Teaching is provided by the case studies, open discussions and solution findings.",


                ]
            },

            {
                "type": "list-bollet",
                "title": "Eligibility Criteria",
                "info": "<b>Follow the below eligibility criteria required applying for MBA in Malta:</b>",
                "img": '',
                "data": [
                    "Applicants need to have a bachelor’s degree with good grades.",
                    "Applicant should clear English language proficiency test with the following grades<br>  IELTS-6.5 <Br>TOEFL-79 <br>PTE-55 <br>iTEP-4.0",
                    "Working professionals should have to submit the work experience certificate in their respective specialized fields.",


                ]
            },


            {
                type: 'text',
                title: 'Admission Procedure(2022-23): Applying for MBA in Malta',
                info: '<b>Below are the easy admission steps required for applying MBA in Malta:</b>',
                data: '<p><b>Step 1:</b> Fill the online application form. Submit the original copies of documents with valid details.</p><br><p><b>Step 2:</b> Wait for the application review process. Usually, it takes a couple of weeks for approval.</p><br><p><b>Step 3:</b>Get an invitation letter and pay the required admission deposit to the university.</p><br><p><b>Step 4:</b> Apply for the visa.</p><br><p><b>Step 5:</b>  Inform your arrival time to the university after the visa confirmation.</p>'
              },


              {
                type: 'text',
                title: '',
                img: '',
                data: '<p><b Note:</b> Conditional admission is provided to all those applicants who meet all the requirements except the English proficiency requirements.</p> '
            },



            {
                "type": "list-bollet",
                "title": "Documents Required",
                "info": "<b>Following are the documents required applying for MBA in Malta:</b>",
                "img": '',
                "data": [
                    "Matriculation Certificate",
                    " Copy of relevant mark sheets (10th,12th, bachelors)",
                    "Copy of passport",
                    "Copy of official invitation letter",
                    "Copy of Passport",
                    " Copy of application form",
                    "Application fee receipt",
                    "Work experience certificate",
                    "Candidates studying under the US education system should submit copies of transcripts with an average GPA of 2.0 for admission.",


                ]
            },



            {
                "type": "table",
                "title": "Cost of Living in Malta                ",
                "info": "<b>Following is the cost of living in Malta:</b>",
                "col": [
                    "Particulars",
                    "Cost in INR",
                     "Cost in USD",
                ],

                "row": [
                    {
                        "Particulars": "<b> Accommodation		</b>",
                        "Cost in INR": "30,000 - 50,000",
                        "Cost in USD": "428 - 714",
                    },

                    {
                        "Particulars": "<b>Food		</b>",
                        "Cost in INR": "9,000 - 15,000",
                        "Cost in USD": "128 - 214",
                    },
                    {
                        "Particulars": "<b>Transport		</b>",
                        "Cost in INR": "1500 - 2000",
                        "Cost in USD": "21 - 28",
                    },

                ]
            },


            {
                type: 'text',
                title: '',
                img: '',
                data: '<p><b Note:</b> 1 USD = 70 Rs (for calculation purpose) </p>'
            },

            {
                "type": "list-bollet",
                "title": "About Malta",
                "info": "<b></b>",
                "img": 'https://www.selectyouruniversity.com/images/malta.jpg',
                "data": [
                    "Malta is the island located in the Mediterranean sea which is about the 97km of the southeast tip of Sicily.",
                    "Phoenicians are the ones who had recognized the strategic importance of Malta with the division of the Roman Empire in A.D.395.",
                    "The Maltese islands are like open-air museums as they are surrounded by medieval towers, wayside chapels, and the oldest human structures in the world.",
                    " The country has a Mediterranean climate with hot summers and mild winters.",
                    "The average annual temperature is around 23°C in Malta.",
                    " Malta is the cultural, administrative & commercial center characterized by fishing, tourism, crafts and agriculture.",
                    "The country has a solid business background with a history of 50 years.",


                ]
            },



            // meta: [{ name: "title", content: "MBA in Malta 2023" },{ name: "description", content: "Study MBA in Malta in top management institutes with affordable fee structure and easy eligibility criteria. MBA degree in Malta has course duration of 2 years." },],link:[{ rel:"canonical", href:"https://www.selectyouruniversity.com/course/mba-in-malta"},]


        ]}
