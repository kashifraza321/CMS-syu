// export const universityofwolverhampton= {
//     "Title": "",
//     "shortTitle": " ",
//     "location": " ",
//     "type": "bb",
//     "rating": "vv",
//     "shareLink": "www.google.com",
//     data: [


//         {
//             type: 'text',
//             title: '',
//             img: '',
//             data: '<p></p><br><p></p><br><p></p><br><p></p><br><p></p>'
//         },

//         {
//             "type": "table",
//             "title": "",
//             "info": "<b></b>",
//             "col": [
//             ],
//             "row": [
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],


//             ]
//         },
//      {
//             "type": "list-bollet",
//             "title": "",
//             "info": "<b></b>",
//             "img": '',
//             "data": [
//                 "",
//                 "",
//                 "",
//                 "",
//                 "",
//                 "",
//                 "",
//                 "",


//             ]
//         },

//         {
//             "type": "table",
//             "title": "",
//             "info": "<b></b>",
//             "col": [
//                 "World	",
//                 "Country",
//             ],

//             "row": [
//                 {
//                     "World": "",
//                     "Country": "",
//                 },

//             ]
//         },

//         {
//                 "type": "list-bollet",
//                 "title": "",
//                 "info": "<b></b>",
//                 "img": '',
//                 "data": [
//                     "",


//                 ]
//             },
//             {
//                 "type": "table",
//                 "title": "",
//                 "info": "<b></b>",
//                 "col": [
//                     "Particular		",
//                     "Amount in USD", 
//                     "Amount in RS", 
//                 ],

//                 "row": [
//                     {
//                         "Particular": "<b></b>",
//                         "Amount in USD":"",
//                         "Amount in RS":"",
//                     },

//                 ]
//             },
//             {
//                 type: 'text',
//                 title: '',
//                 img: '',
//                 data: '<p><b> Note:</b> </p> '
//             },



//         {
//             type:'meta',
//             data:[
//               {name: "description" , content:"", itemprop:"", property: "",scheme:'' },
//               {name: "og:type" , content:"website", itemprop:"", property: "", },
//               {name: "og:image" , content:"", itemprop:"", property: "",scheme:'' },
//               {name: "og:description" , content:"", itemprop:"", property: "",scheme:'' },
//               {name: "og:url" , content:"", itemprop:"", property: "",scheme:'' },


//               {name: "charset" , content:"utf-8", itemprop:"", property: "",scheme:'' },
//               {name: "google" , content:"notranslate", itemprop:"", property: "",scheme:'' },
//               {name: "viewport" , content:"width=device-width, initial-scale=1, shrink-to-fit=no, maximum-scale=1, user-scalable=no", itemprop:"", property: "",scheme:'' },




//             ]
//           },
//           {
//             type:'link',
//             data:[
//               { rel:'alternate', href:'https://www.selectyouruniversity.com/uk/university-of-wolverhampton hreflang=en-Us '},
//               { rel:'canonical', href:''},
//               { rel:'icon', href:'../images/fevicon.png type="image/png"'},
//             ],
//             url:""
//           },
//           {
//             type:"page-Title",
//             data:"",
//           }

//     ]}



export const yerevanstatemedicaluniversity = {
    "Title": "YEREVAN STATE MEDICAL UNIVERSITY",
    "shortTitle": "Yerevan State Medical University ",
    "location": " Armenia ",
    "type": "bb",
    "rating": "vv",
    "shareLink": "www.google.com",
    "url":"yerevan-state-medical-university",
    "info": [


        {
            type: 'text',
            title: 'About Yerevan State Medical University, Armenia',
            img: 'https://www.selectyouruniversity.com/images/armenia-universities/yerevan-state-medical-university-college.jpg',
            data: '<p>In 1920, <b>Yerevan State Medical University</b> was established.Yerevan State Medical University is one of the top and the best medical institutes in Armenia.</p><br><p>As it is the oldest university in Armenia, almost hundred years old, it has trained thousands of doctors. Yerevan State Medical University has highly qualified and experienced teachers.</p><br><p>Thus, students can fulfill their dream of studying MBBS at the Yerevan State Medical University.</p>'
        },

        {
            "type": "table",
            "title": "Yerevan State Medical University - Quick Highlights 2022",
            "info": "<b>Given below is the table for quick highlights about Yerevan State Medical University:</b>",
            "col": [
            ],
            "row": [
                ["<b>Intake for MBBS Course	</b>", "September"],
                ["<b>Processing Time for MBBS Admission	</b>", "45 - 60 days"],
                ["<b>Location	</b>", "Yerevan, Kazakhstan"],
                ["<b>Eligibility Criteria	</b>", "50% in PCB for General<br> 40% for Reserved category"],
                ["<b>NEET Exam	</b>", "Yes, it is compulsory"],
                ["<b>Annual Tuition Fees (Approx.)</b>", "	Rs. 4.62 Lacs / Year"],
                ["<b>University Ranking</b>", "	Country - 7<br>  World - 6879"],
                ["<b>Course Duration	</b>", "5 years + 1 year of internship"],
                ["<b>University Recognition	</b>", "NMC, WHO"],
                ["<b>Medium of Education	</b>", "English"],


            ]
        },
        {
            "type": "list-bollet",
            "title": "Why Study MBBS at Yerevan State Medical University?",
            "info": "<b>Below are some of the benefits of studying MBBS at Yerevan State Medical University:</b>",
            "img": '',
            "data": [
                "Students are not required to pay any donation or capitation fee for their MBBS admission in the Armenian medical universities. They only need to pay the MBBS fees in Armenia online or by the other modes of payment in order to secure their seat.",
                "Living cost in Armenia is affordable and the tuition fees are also less.",
                "Students are not required to appear for any kind of entrance test",
                " One more added advantage for all the Indian students is that the top medical universities in Armenia are recognized and approved by the National Medical Commission (NMC).",
                "There is no english language exam like IELTS or TOEFL required.",
                " There are Indian mess and Indian restaurants available in Yerevan, so the students never face any problem related to food.",
                "The quality of education in Armenia is as good as countries like the UK, the USA and India and that too at a lower price.",
                "The language of education in medical colleges in Armenia is English.",


            ]
        },

        {
            "type": "table",
            "title": "Yerevan State Medical University - Ranking 2022",
            "info": "<b>According to 4icu.org, following is the country and world ranking for Yerevan State Medical University:</b>",
            "col": [
                "World	",
                "Country",
            ],

            "row": [
                {
                    "World": "7	",
                    "Country": "6879",
                },

            ]
        },

        {
            "type": "list-bollet",
            "title": "Accreditation and Recognition",
            "info": "<b>The MBBS, MD, and BDS degrees of Yerevan State Medical University are recognized by:</b>",
            "img": '',
            "data": [
                "National Medical Commission (NMC)",
                "World Health Organization (WHO)",
                "Ministry of Science, Education, Culture, and Sport of the Republic of Armenia.",


            ]
        },
        {
            "type": "table",
            "title": "Cost of Living at Yerevan",
            "info": "<b>The cost of living at Yerevan city is as follows:</b>",
            "col": [
                "Activity	",
                "Cost",
            ],

            "row": [
                {
                    "Activity": "<b>Things of daily need (Milk, Groceries, Bread, etc.)	</b>",
                    "Cost": "Ranges in between Rs.30 - Rs.500",
                },
                {
                    "Activity": "<b>Eating at a mid-range restaurant (for 2 people)	</b>",
                    "Cost": "Rs.1800 - Rs.2000",
                },
                {
                    "Activity": "<b>One way ticket of any local transport	</b>",
                    "Cost": "Rs.15",
                },
                {
                    "Activity": "<b>A monthly pass for local transport	</b>",
                    "Cost": "Rs. 900",
                },
                {
                    "Activity": "<b>Monthly rent for a 1 bedroom apartment	                        </b>",
                    "Cost": "cost between Rs.14,000 - Rs.25,000                        ",
                },

            ]
        },
        {
            type: 'text',
            title: '',
            img: '',
            data: '<p><b> Note:</b> 1$ = 70 Rs.</p> '
        },
        {
            "type": "table",
            "title": "Yerevan State Medical University: FMGE Performance 2021",
            "info": "<b>Find the passing percent and appeared students in year 2021 for Yerevan State Medical University is here in the table below:</b>",
            "col": [
                "Name of University			",
                "Appeared",
                "Total Pass",
                "Pass %",
            ],

            "row": [
                {
                    "Name of University": "<b>Yerevan State Medical University		</b>",
                    "Appeared": "425	",
                    "Total Pass": "109",
                    "Pass %": "25.65%",
                },


                {
                    "type": "list-bollet",
                    "title": "About Yerevan City",
                    "info": "<b>Interesting facts about the Yerevan city are as follows:-</b>",
                    "img": 'https://www.selectyouruniversity.com/images/armenia-universities/yerevan-state-medical-university-college.jpg',
                    "data": [
                        "Yerevan city is the capital city of Armenia.",
                        " Yerevan is the industrial, cultural, and administrative center of Armenia.",
                        "Yerevan offers a healthy and comfortable life to the students.",
                        "Being the capital city of Armenia, Yerevan has all the facilities such as shopping malls, cafes, transport, and other recreational activities easily accessible for the students.",
                        "This city is one of the world’s oldest continuously inhabited cities.",
                        " This is also the largest city of Armenia.",
                        "There are a number of patients in the hospitals for students to practice their medical skills, as the city has a large population.",
                        "  Yerevan houses the Indian Embassy.",
                        "The people of Yerevan are helpful towards the new entrants in the city.",
                        "There is a good availability of connecting flights from Yerevan to countries world over and it is very good and people are always satisfied with their services.",
                        "The Yerevan city has a moderate temperature throughout the year and it makes all season material easily available.",


                    ]
                },



            ]
        },

    ],
    meta: [{ name: "title", content: "Yerevan State Medical University, Armenia" },{ name: "description", content: "Yerevan State Medical University was established.Yerevan State Medical University is one of the top and the best medical institutes in Armenia." },],link: [{ rel: "canonical", href: "https://www.selectyouruniversity.com/university/yerevan-state-medical-university"}]
}